package com.bridgecast.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.mediarouter.app.MediaRouteButton
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    private lateinit var server: LocalServer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { CastContext.getSharedInstance(this) }
        server = LocalServer(applicationContext).also { it.start() }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }

    override fun onDestroy() {
        server.stop()
        super.onDestroy()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_IMAGES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasPerms() = perms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun guessMime(url: String) = when {
        url.contains(".m3u8") -> "application/x-mpegURL"
        url.contains(".mpd") -> "application/dash+xml"
        url.contains(".webm") -> "video/webm"
        url.contains(".mkv") -> "video/x-matroska"
        else -> "video/mp4"
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App() {
        val ctx = applicationContext
        val scope = rememberCoroutineScope()
        var tab by remember { mutableIntStateOf(0) }
        var devices by remember { mutableStateOf(listOf<DlnaDevice>()) }
        var selected by remember { mutableStateOf<DlnaDevice?>(null) }
        var status by remember { mutableStateOf("") }
        var showPicker by remember { mutableStateOf(false) }
        var scanning by remember { mutableStateOf(false) }
        var granted by remember { mutableStateOf(hasPerms()) }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            granted = hasPerms()
        }

        fun scan() {
            scope.launch {
                scanning = true
                devices = runCatching { SsdpDiscovery(ctx).search() }.getOrDefault(emptyList())
                scanning = false
            }
        }

        fun cast(url: String, title: String, mime: String, kind: Kind) {
            scope.launch {
                val d = selected
                status = try {
                    if (d != null) {
                        withContext(Dispatchers.IO) { DlnaController.play(d, url, title, mime, kind) }
                        "▶ ${d.name}: $title"
                    } else if (ChromecastController.play(ctx, url, title, mime, kind)) {
                        "▶ Chromecast: $title"
                    } else {
                        showPicker = true
                        "اختر جهاز العرض أولاً"
                    }
                } catch (e: Exception) {
                    "خطأ: ${e.message}"
                }
            }
        }

        val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val mime = contentResolver.getType(uri) ?: "video/mp4"
                val kind = when {
                    mime.startsWith("audio") -> Kind.AUDIO
                    mime.startsWith("image") -> Kind.IMAGE
                    else -> Kind.VIDEO
                }
                cast(server.register(uri), uri.lastPathSegment ?: "file", mime, kind)
            }
        }

        LaunchedEffect(Unit) {
            if (!granted) permLauncher.launch(perms())
            scan()
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Bridgecast") },
                    actions = {
                        TextButton(onClick = { showPicker = true }) { Text(selected?.name ?: "📺 جهاز") }
                        AndroidView(factory = { c ->
                            MediaRouteButton(c).also { CastButtonFactory.setUpMediaRouteButton(c, it) }
                        })
                    }
                )
            },
            bottomBar = {
                Column {
                    val d = selected
                    if (status.isNotBlank() || d != null) {
                        Surface(tonalElevation = 3.dp) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(status.ifBlank { "الجهاز: ${d?.name}" }, Modifier.weight(1f), maxLines = 1)
                                if (d != null) {
                                    TextButton(onClick = { scope.launch(Dispatchers.IO) { runCatching { DlnaController.resume(d) } } }) { Text("▶") }
                                    TextButton(onClick = { scope.launch(Dispatchers.IO) { runCatching { DlnaController.pause(d) } } }) { Text("⏸") }
                                    TextButton(onClick = { scope.launch(Dispatchers.IO) { runCatching { DlnaController.stop(d) } } }) { Text("⏹") }
                                }
                            }
                        }
                    }
                    NavigationBar {
                        listOf("🎬" to "فيديو", "🎵" to "موسيقى", "🖼️" to "صور", "🔗" to "رابط")
                            .forEachIndexed { i, (emoji, label) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(emoji, fontSize = 20.sp) }, label = { Text(label) }
                                )
                            }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0, 1, 2 -> LibraryTab(
                        kind = Kind.values()[tab], granted = granted,
                        onRequest = { permLauncher.launch(perms()) },
                        onItem = { cast(server.register(it.uri), it.title, it.mime, it.kind) }
                    )
                    else -> LinkTab(
                        onCast = { cast(it, "Bridgecast", guessMime(it), Kind.VIDEO) },
                        onPick = { filePicker.launch(arrayOf("video/*", "audio/*", "image/*")) }
                    )
                }
            }
        }

        if (showPicker) {
            AlertDialog(
                onDismissRequest = { showPicker = false },
                confirmButton = { TextButton(onClick = { showPicker = false }) { Text("إغلاق") } },
                title = { Text("اختر جهاز العرض") },
                text = {
                    Column {
                        TextButton(onClick = { scan() }) { Text(if (scanning) "جارٍ البحث..." else "🔄 بحث DLNA") }
                        Text("Chromecast: اضغط أيقونة الكاست في أعلى الشاشة", style = MaterialTheme.typography.bodySmall)
                        LazyColumn(Modifier.heightIn(max = 280.dp)) {
                            items(devices) { d ->
                                ListItem(
                                    headlineContent = { Text(d.name) },
                                    trailingContent = { if (selected == d) Text("✓") },
                                    modifier = Modifier.clickable { selected = d; showPicker = false }
                                )
                            }
                        }
                        if (selected != null) {
                            TextButton(onClick = { selected = null; showPicker = false }) {
                                Text("إلغاء اختيار DLNA (استخدام Chromecast)")
                            }
                        }
                    }
                }
            )
        }
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun LibraryTab(kind: Kind, granted: Boolean, onRequest: () -> Unit, onItem: (MediaItem) -> Unit) {
    if (!granted) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("نحتاج إذن الوصول إلى الوسائط")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onRequest) { Text("منح الإذن") }
        }
        return
    }
    val ctx = LocalContext.current
    val list by produceState(emptyList<MediaItem>(), kind) {
        value = withContext(Dispatchers.IO) { runCatching { MediaRepository.load(ctx, kind) }.getOrDefault(emptyList()) }
    }
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("لا توجد ملفات") }
        return
    }
    if (kind == Kind.AUDIO) {
        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.id }) { m ->
                ListItem(
                    leadingContent = { Text("🎵", fontSize = 24.sp) },
                    headlineContent = { Text(m.title, maxLines = 1) },
                    supportingContent = { Text(fmt(m.durationMs)) },
                    modifier = Modifier.clickable { onItem(m) }
                )
            }
        }
    } else {
        val loader = remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build() }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            gridItems(list, key = { it.id }) { m ->
                Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).clickable { onItem(m) }) {
                    AsyncImage(
                        model = m.uri, imageLoader = loader, contentDescription = m.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                    if (kind == Kind.VIDEO) {
                        Text(
                            fmt(m.durationMs), color = Color.White, fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.BottomEnd).background(Color(0x99000000)).padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LinkTab(onCast: (String) -> Unit, onPick: () -> Unit) {
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("رابط الفيديو (mp4 / m3u8 / mpd)") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { onCast(url.trim()) }, enabled = url.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text("بث الرابط")
        }
        OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Text("اختيار ملف من التخزين") }
    }
}
