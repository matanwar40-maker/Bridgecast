package com.bridgecast.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

enum class Kind { VIDEO, AUDIO, IMAGE }

data class MediaItem(
    val id: Long, val uri: Uri, val title: String,
    val kind: Kind, val durationMs: Long, val mime: String
)

/** يقرأ مكتبة الوسائط من MediaStore. */
object MediaRepository {
    fun load(ctx: Context, kind: Kind): List<MediaItem> {
        val base = when (kind) {
            Kind.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            Kind.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            Kind.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val defMime = when (kind) { Kind.VIDEO -> "video/mp4"; Kind.AUDIO -> "audio/mpeg"; Kind.IMAGE -> "image/jpeg" }
        val cols = mutableListOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.MIME_TYPE
        )
        if (kind != Kind.IMAGE) cols += "duration"
        val out = mutableListOf<MediaItem>()
        ctx.contentResolver.query(
            base, cols.toTypedArray(), null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iDur = c.getColumnIndex("duration")
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out += MediaItem(
                    id, ContentUris.withAppendedId(base, id), c.getString(iName) ?: "",
                    kind, if (iDur >= 0) c.getLong(iDur) else 0L, c.getString(iMime) ?: defMime
                )
            }
        }
        return out
    }
}
